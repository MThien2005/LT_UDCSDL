package Gui;

import java.awt.EventQueue;
import java.util.Date;
import java.util.List;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

import Entity.Student;
import Service.ServiceStudent;

import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.text.SimpleDateFormat;
import java.awt.event.ActionEvent;
import javax.swing.JTextField;
import javax.swing.JLabel;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class StudentJframe extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JScrollPane scrollPane;
	private JTable table;
	
	ServiceStudent stuservice = new ServiceStudent();
	List<Student> stulist;
	private JButton btn_delete;
	private JButton btn_insert;
	private JTextField txt_id;
	private JTextField txt_name;
	private JTextField txt_gen;
	private JTextField txt_birthday;
	private JLabel lblNewLabel;
	private JLabel lblName;
	private JLabel lblGen;
	private JLabel lblBirthday;
	private JButton btn_update;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					StudentJframe frame = new StudentJframe();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	
	public StudentJframe() {
		initGUI();
		loadData();
	}
	
	public void loadData() {
		
		DefaultTableModel model = new DefaultTableModel();
		String dsCot [] = {"id", "name", "gen", "birthday"};
		for (String tencot : dsCot) {
			model.addColumn(tencot);
		}
		
		stulist =stuservice.getAll();
		
		for (Student stu : stulist) {
			String gen = "";
			
			if(stu.isGen() == true) {
				gen = "male";
			}else {
				gen = "female";
			}
			Object[] obj = {
					stu.getId(),
					stu.getName(),
					gen,
					stu.getBirthday()
			};
			model.addRow(obj);
		}
	
		table.setModel(model);
	}
	
	private void initGUI() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 695, 497);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		
				setContentPane(contentPane);
		contentPane.setLayout(null);
		
		scrollPane = new JScrollPane();
		scrollPane.setBounds(10, 231, 659, 216);
		contentPane.add(scrollPane);
		
		table = new JTable();
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				
			    int row = table.getSelectedRow();

			    txt_id.setText(table.getValueAt(row, 0).toString());
			    txt_name.setText(table.getValueAt(row, 1).toString());
			    txt_gen.setText(table.getValueAt(row, 2).toString());
			    txt_birthday.setText(table.getValueAt(row, 3).toString());	    
			    txt_id.setEditable(false);
			}
		});
		scrollPane.setViewportView(table);
		
		btn_delete = new JButton("Delete");
		btn_delete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			
			    int row = table.getSelectedRow(); 
			    
			    if (row == -1) {
			        JOptionPane.showMessageDialog(StudentJframe.this, "Vui lòng chọn một dòng để xóa!");
			        return;
			    }

			    int confirm = JOptionPane.showConfirmDialog(StudentJframe.this,  "Bạn có chắc chắn muốn xóa sinh viên này?", "Xác nhận", JOptionPane.YES_NO_OPTION);
			    
			    if (confirm == JOptionPane.YES_OPTION) {
			        try {
			        		int id = Integer.parseInt(table.getValueAt(row, 0).toString());

			   
			            ServiceStudent sv = new ServiceStudent();
			            if (sv.delete(id)) {
			                JOptionPane.showMessageDialog(StudentJframe.this, "Xóa thành công!");
			                loadData(); 
			            } else {
			                JOptionPane.showMessageDialog(StudentJframe.this, "Xóa thất bại!");
			            }
			        } catch (Exception e1) {
			            JOptionPane.showMessageDialog(StudentJframe.this, "Lỗi: " + e1.getMessage());
			        }
			    }
			}
		});
		btn_delete.setBounds(448, 26, 89, 23);
		contentPane.add(btn_delete);
		
		btn_insert = new JButton("Insert");
		btn_insert.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					
					String name = txt_name.getText().toLowerCase();
					String genStr = txt_gen.getText().toLowerCase();
					String birthdayStr = txt_birthday.getText().trim();
					if (name.isEmpty() || birthdayStr.isEmpty()) {
						return;
					}
					boolean gender = genStr.equals("male") || genStr.equals("nam") || genStr.equals(true);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.S");
					sdf.setLenient(false);
					Date birthday = sdf.parse(birthdayStr);
					
					Student stu = new Student();
					stu.setName(name);
					stu.setGen(gender);
					stu.setBirthday(birthday);
					
					ServiceStudent service = new ServiceStudent();
					boolean flag = service.insert(stu);
					JOptionPane.showMessageDialog(StudentJframe.this, "Them thanh cong!");
					if(flag) {
						txt_name.setText("");
						txt_gen.setText("");
						txt_birthday.setText("");
						txt_id.setText("");
						
						loadData();
						
					}else {
						JOptionPane.showMessageDialog(StudentJframe.this, "Them that bai!");
					}
				} catch (Exception e2) {
					// TODO: handle exception
				}
			}
		});
		btn_insert.setBounds(448, 65, 89, 23);
		contentPane.add(btn_insert);
		
		txt_id = new JTextField();
		txt_id.setBounds(131, 27, 208, 20);
		contentPane.add(txt_id);
		txt_id.setColumns(10);
		
		txt_name = new JTextField();
		txt_name.setColumns(10);
		txt_name.setBounds(131, 66, 208, 20);
		contentPane.add(txt_name);
		
		txt_gen = new JTextField();
		txt_gen.setColumns(10);
		txt_gen.setBounds(131, 109, 208, 20);
		contentPane.add(txt_gen);
		
		txt_birthday = new JTextField();
		txt_birthday.setColumns(10);
		txt_birthday.setBounds(131, 150, 208, 20);
		contentPane.add(txt_birthday);
		
		lblNewLabel = new JLabel("ID");
		lblNewLabel.setBounds(50, 30, 46, 14);
		contentPane.add(lblNewLabel);
		
		lblName = new JLabel("Name");
		lblName.setBounds(50, 69, 46, 14);
		contentPane.add(lblName);
		
		lblGen = new JLabel("Gen");
		lblGen.setBounds(50, 112, 46, 14);
		contentPane.add(lblGen);
		
		lblBirthday = new JLabel("BirthDay");
		lblBirthday.setBounds(50, 150, 71, 20);
		contentPane.add(lblBirthday);
		
		btn_update = new JButton("Update");
		btn_update.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
			        int id = Integer.parseInt(txt_id.getText());
			        String name = txt_name.getText();
			        String genStr = txt_gen.getText().toLowerCase();
			        boolean gender = genStr.equals("male") || genStr.equals("nam") || genStr.equals("true");
			        
			        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
			        Date birthday = sdf.parse(txt_birthday.getText());


			        Student stu = new Student();
			        stu.setId(id);
			        stu.setName(name);
			        stu.setGen(gender);
			        stu.setBirthday(birthday);

			        ServiceStudent sv = new ServiceStudent();
			        if (sv.update(stu)) {
			            JOptionPane.showMessageDialog(StudentJframe.this, "Cập nhật thành công!");
			            loadData(); 
			        } else {
			            JOptionPane.showMessageDialog(StudentJframe.this, "Cập nhật thất bại!");
			        }
			    } catch (Exception e1) {
			        JOptionPane.showMessageDialog(StudentJframe.this, "Lỗi dữ liệu: " + e1.getMessage());
			    }
			}
		});
		btn_update.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				int row = table.getSelectedRow();
			    
			    txt_id.setText(table.getValueAt(row, 0).toString());

			    txt_name.setText(table.getValueAt(row, 1).toString());

			    txt_gen.setText(table.getValueAt(row, 2).toString());

			    txt_birthday.setText(table.getValueAt(row, 3).toString());

			    txt_id.setEditable(false);
			}
		});
		btn_update.setBounds(448, 108, 89, 23);
		contentPane.add(btn_update);
	}
}
