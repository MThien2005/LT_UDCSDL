package Service;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import Entity.Student;

public class ServiceStudent {

	EntityManagerFactory emf = Persistence.createEntityManagerFactory("lyminhthien_dh52301845");
	
	public List<Student> getAll() {
		
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		@SuppressWarnings("unchecked")
		List<Student> studentlist = em.createQuery("from Student").getResultList();
		em.getTransaction().commit();
		em.close();
		return studentlist;
	}
	
	public boolean insert(Student stu) {
		EntityManager em = emf.createEntityManager();
		try {
			em.getTransaction().begin();
			em.persist(stu);
			em.getTransaction().commit();
			return true;
		} catch (Exception e) {
			// TODO: handle exception
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			return false;
		}
		finally {
			em.close();
		}
	}
	
	public boolean delete(int id) {
	    EntityManager em = emf.createEntityManager();
	    try {
	        em.getTransaction().begin();
	        
	        Student stu = em.find(Student.class, id);
	        if (stu != null) {
	            em.remove(stu); 
	            em.getTransaction().commit();
	            return true;
	        }
	        return false;
	    } catch (Exception e) {
	        if (em.getTransaction().isActive()) {
	            em.getTransaction().rollback();
	        }
	        e.printStackTrace();
	        return false;
	    } finally {
	        em.close();
	    }
	}
	public boolean update(Student stu) {
	    EntityManager em = emf.createEntityManager();
	    try {
	        em.getTransaction().begin();
	       
	        em.merge(stu); 
	        em.getTransaction().commit();
	        return true;
	    } catch (Exception e) {
	        if (em.getTransaction().isActive()) {
	            em.getTransaction().rollback();
	        }
	        e.printStackTrace();
	        return false;
	    } finally {
	        em.close();
	    }
	}
}
