package Entity;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Student {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String name;
	private boolean gen;
	private Date birthday;
	
	public Student(int id, String name, boolean gen, Date birthday) {
		super();
		this.id = id;
		this.name = name;
		this.gen = gen;
		this.birthday = birthday;
	}
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isGen() {
		return gen;
	}

	public void setGen(boolean gen) {
		this.gen = gen;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public Student() {
		super();
	}
	
	@Override
	public String toString() {
		return "Student [id=" + id + ", name=" + name + ", gen=" + gen + ", birthday=" + birthday + "]";
	}
	
	
}
